const navLinks = document.querySelectorAll("[data-page]");
const pages = document.querySelectorAll(".page");

function showPage(pageId) {
  pages.forEach(page => {
    page.classList.toggle("active-page", page.id === pageId);
  });

  document.querySelectorAll("nav a").forEach(link => {
    link.classList.toggle("active", link.dataset.page === pageId);
  });

  window.scrollTo({ top: 0, behavior: "smooth" });
}

navLinks.forEach(link => {
  link.addEventListener("click", event => {
    event.preventDefault();
    showPage(link.dataset.page);
  });
});

const nInput = document.getElementById("n");
const pInput = document.getElementById("p");
const error = document.getElementById("error");

function calculateStatistics() {
  const n = Number(nInput.value);
  const p = Number(pInput.value);

  error.textContent = "";

  if (nInput.value === "" || pInput.value === "") {
    error.textContent = "Please enter both n and p.";
    return;
  }

  if (!Number.isInteger(n) || n <= 0) {
    error.textContent = "Number of trials (n) must be a positive integer.";
    return;
  }

  if (p < 0 || p > 1) {
    error.textContent = "Probability of success (p) must be between 0 and 1.";
    return;
  }

  const mean = n * p;
  const variance = n * p * (1 - p);
  const standardDeviation = Math.sqrt(variance);
  const secondMoment = variance + Math.pow(mean, 2);

  let skewness = 0;
  if (variance > 0) {
    skewness = (1 - 2 * p) / Math.sqrt(variance);
  }

  document.getElementById("displayN").textContent = n;
  document.getElementById("displayP").textContent = p;

  document.getElementById("mean").textContent = mean.toFixed(2);
  document.getElementById("variance").textContent = variance.toFixed(2);
  document.getElementById("stdDev").textContent = standardDeviation.toFixed(4);
  document.getElementById("secondMoment").textContent = secondMoment.toFixed(2);
  document.getElementById("skewness").textContent = skewness.toFixed(4);
}

document.getElementById("applyBtn").addEventListener("click", calculateStatistics);

// Calculate and display the requested default values immediately.
calculateStatistics();

function combination(n, k) {
  if (k < 0 || k > n) return 0;
  k = Math.min(k, n - k);
  let result = 1;

  for (let i = 1; i <= k; i++) {
    result = result * (n - k + i) / i;
  }

  return result;
}

document.getElementById("pmfBtn").addEventListener("click", () => {
  const n = Number(nInput.value);
  const p = Number(pInput.value);
  const kInput = document.getElementById("k");
  const k = Number(kInput.value);
  const pmfError = document.getElementById("pmfError");

  pmfError.textContent = "";

  if (nInput.value === "" || pInput.value === "") {
    pmfError.textContent = "Please enter valid n and p first.";
    return;
  }

  if (!Number.isInteger(n) || n <= 0) {
    pmfError.textContent = "Number of trials (n) must be a positive integer.";
    return;
  }

  if (p < 0 || p > 1) {
    pmfError.textContent = "Probability of success (p) must be between 0 and 1.";
    return;
  }

  if (kInput.value === "") {
    pmfError.textContent = "Please enter k.";
    return;
  }

  if (!Number.isInteger(k) || k < 0 || k > n) {
    pmfError.textContent = "k must be a whole number between 0 and n.";
    return;
  }

  const probability =
    combination(n, k) *
    Math.pow(p, k) *
    Math.pow(1 - p, n - k);

  document.getElementById("pmfProbability").textContent =
    probability.toFixed(6);

  document.getElementById("pmfPercentage").textContent =
    (probability * 100).toFixed(4) + "%";

  document.getElementById("pmfMeaning").textContent =
    `This means there is a ${(probability * 100).toFixed(4)}% probability of getting exactly ${k} success${k === 1 ? "" : "es"} in ${n} trials.`;
});


function calculateCDF() {
  const n = Number(document.getElementById("n").value);
  const p = Number(document.getElementById("p").value);
  const kInput = document.getElementById("cdf-k");
  const error = document.getElementById("cdf-error");
  const result = document.getElementById("cdf-result");
  const complementResult = document.getElementById("cdf-complement-result");

  error.textContent = "";
  result.textContent = "—";
  complementResult.textContent = "—";

  if (!Number.isInteger(n) || n <= 0) {
    error.textContent = "Please enter a positive integer for n.";
    return;
  }

  if (!Number.isFinite(p) || p < 0 || p > 1) {
    error.textContent = "Please enter p between 0 and 1.";
    return;
  }

  if (kInput.value.trim() === "") {
    error.textContent = "Please enter k.";
    return;
  }

  const k = Number(kInput.value);

  if (!Number.isInteger(k)) {
    error.textContent = "k must be an integer.";
    return;
  }

  if (k < 0 || k > n) {
    error.textContent = `k must be between 0 and ${n}.`;
    return;
  }

  let cdf = 0;

  // P(X <= k) = sum of P(X = x) for x = 0 to k
  for (let x = 0; x <= k; x++) {
    cdf += combination(n, x) *
      Math.pow(p, x) *
      Math.pow(1 - p, n - x);
  }

  // Protect against tiny floating-point errors.
  cdf = Math.min(1, Math.max(0, cdf));
  const complement = Math.min(1, Math.max(0, 1 - cdf));

  result.textContent = cdf.toFixed(6);
  complementResult.textContent = complement.toFixed(6);
}

const cdfButton = document.getElementById("calculate-cdf");
if (cdfButton) {
  cdfButton.addEventListener("click", calculateCDF);
}

// ---------------- Binomial PMF Bar Chart ----------------
const pmfChartContainer = document.getElementById("pmfChart");

function renderPMFChart() {
  if (!pmfChartContainer) return;

  const n = Number(nInput.value);
  const p = Number(pInput.value);

  if (!Number.isInteger(n) || n <= 0 || !Number.isFinite(p) || p < 0 || p > 1) {
    pmfChartContainer.innerHTML = '<p class="error">Enter valid n and p values to display the graph.</p>';
    return;
  }

  const points = [];
  for (let x = 0; x <= n; x++) {
    points.push({ x, probability: combination(n, x) * Math.pow(p, x) * Math.pow(1 - p, n - x) });
  }

  const width = Math.max(760, (n + 1) * 42);
  const height = 390;
  const margin = { top: 32, right: 28, bottom: 58, left: 64 };
  const plotWidth = width - margin.left - margin.right;
  const plotHeight = height - margin.top - margin.bottom;
  const maxProbability = Math.max(...points.map(point => point.probability), 0.01);
  const yMax = maxProbability * 1.15;
  const mean = n * p;
  const step = plotWidth / (n + 1);
  const barWidth = Math.max(2, step * 0.72);

  const y = value => margin.top + plotHeight - (value / yMax) * plotHeight;
  const xCenter = x => margin.left + step * (x + 0.5);
  const formatProbability = value => value.toFixed(6);

  const yTicks = 5;
  let svg = `<svg viewBox="0 0 ${width} ${height}" role="img" aria-label="Binomial probability mass function for n=${n} and p=${p}">`;

  for (let i = 0; i <= yTicks; i++) {
    const value = (yMax / yTicks) * i;
    const yy = y(value);
    svg += `<line class="pmf-gridline" x1="${margin.left}" y1="${yy}" x2="${width - margin.right}" y2="${yy}" />`;
    svg += `<text class="pmf-tick-label" x="${margin.left - 10}" y="${yy + 4}" text-anchor="end">${value.toFixed(3)}</text>`;
  }

  svg += `<line class="pmf-axis" x1="${margin.left}" y1="${margin.top + plotHeight}" x2="${width - margin.right}" y2="${margin.top + plotHeight}" />`;
  svg += `<line class="pmf-axis" x1="${margin.left}" y1="${margin.top}" x2="${margin.left}" y2="${margin.top + plotHeight}" />`;

  // Mean reference line: E[X] = np
  const meanX = margin.left + step * (mean + 0.5);
  svg += `<line class="pmf-mean-line" x1="${meanX}" y1="${margin.top}" x2="${meanX}" y2="${margin.top + plotHeight}" />`;
  svg += `<text class="pmf-mean-label" x="${Math.min(meanX + 7, width - 110)}" y="${margin.top + 14}">Mean = ${mean.toFixed(2)}</text>`;

  points.forEach(point => {
    const center = xCenter(point.x);
    const barHeight = (point.probability / yMax) * plotHeight;
    const barX = center - barWidth / 2;
    const barY = margin.top + plotHeight - barHeight;
    svg += `<rect class="pmf-bar" x="${barX}" y="${barY}" width="${barWidth}" height="${Math.max(0, barHeight)}" rx="2" data-x="${point.x}" data-probability="${point.probability}" />`;

    const showLabel = n <= 35 || point.x % Math.ceil(n / 25) === 0;
    if (showLabel) {
      svg += `<text class="pmf-tick-label" x="${center}" y="${margin.top + plotHeight + 20}" text-anchor="middle">${point.x}</text>`;
    }
  });

  svg += `<text class="pmf-axis-title" x="${width / 2}" y="${height - 8}" text-anchor="middle">Number of successes X</text>`;
  svg += `<text class="pmf-axis-title" transform="translate(17 ${height / 2}) rotate(-90)" text-anchor="middle">Probability P(X)</text>`;
  svg += `</svg>`;

  pmfChartContainer.innerHTML = svg;

  const tooltip = document.createElement("div");
  tooltip.className = "pmf-tooltip";
  document.body.appendChild(tooltip);

  pmfChartContainer.querySelectorAll(".pmf-bar").forEach(bar => {
    bar.addEventListener("mouseenter", event => {
      const x = Number(bar.dataset.x);
      const probability = Number(bar.dataset.probability);
      tooltip.innerHTML = `<strong>X = ${x}</strong><br>P(X = ${x}) = ${formatProbability(probability)}`;
      tooltip.style.display = "block";
      positionPMFTooltip(event);
    });
    bar.addEventListener("mousemove", positionPMFTooltip);
    bar.addEventListener("mouseleave", () => {
      tooltip.style.display = "none";
    });
  });

  function positionPMFTooltip(event) {
    const offset = 14;
    tooltip.style.left = `${Math.min(event.clientX + offset, window.innerWidth - tooltip.offsetWidth - 10)}px`;
    tooltip.style.top = `${Math.min(event.clientY + offset, window.innerHeight - tooltip.offsetHeight - 10)}px`;
  }
}

// Update automatically whenever n or p changes, as requested.
nInput.addEventListener("input", renderPMFChart);
pInput.addEventListener("input", renderPMFChart);
nInput.addEventListener("change", renderPMFChart);
pInput.addEventListener("change", renderPMFChart);

// Initial chart for the default n and p.
renderPMFChart();
