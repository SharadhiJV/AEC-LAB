# Discrete Probability Distributions — Prompt 4

Prompt 4 adds a Binomial PMF calculator.

## PMF
For X ~ Binomial(n,p), the application calculates:

P(X = k) = C(n,k) × p^k × (1-p)^(n-k)

The student enters k and the application validates:

0 <= k <= n

The result is displayed as:
- Probability
- Percentage
- Mathematical expression
- One-sentence interpretation

Prompt 3 statistics remain available.

## Default values
n = 20
p = 0.35

## Run
Open index.html in a browser.


### Prompt 5 — Binomial CDF
- Enter k to calculate P(X ≤ k).
- Calculates P(X > k) = 1 − P(X ≤ k).
- Validates that k is an integer from 0 to n.
